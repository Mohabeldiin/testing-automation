(function( $ ) {
    "use strict";
} )( jQuery );
