<?php
/*
Plugin Name: MyHome WP All Import
Description: This plugin integrate MyHome with WP All Import plugin
Version: 1.0.0
Plugin URI: https://myhometheme.net
*/

if (!class_exists(Price_Attribute::class)) {
    return;
}

use MyHomeCore\Attributes\Price_Attribute;
use MyHomeCore\Estates\Prices\Currencies;
use MyHomeCore\Terms\Term_Factory;

require 'rapid-addon.php';

add_action('init', function () {
    if ( ! defined('PMXI_VERSION')) {
        return;
    }

    $addon = new RapidAddon('MyHome Theme', 'myhome');
    $addon->run(['themes' => ['MyHome']]);


    foreach (\MyHomeCore\Attributes\Attribute_Factory::get() as $attribute) {
        if ($attribute instanceof \MyHomeCore\Attributes\Text_Attribute) {
            continue;
        }

        if (
            $attribute instanceof \MyHomeCore\Attributes\Number_Attribute
            && ! $attribute instanceof \MyHomeCore\Attributes\Price_Attribute
        ) {
            $addon->add_field($attribute->get_ID(), $attribute->get_name(), 'text');
            continue;
        }

        if ($attribute instanceof \MyHomeCore\Attributes\Price_Attribute) {
            foreach (myhome_get_price_keys() as $key => $label) {
                $addon->add_field($key, $label, 'text');
            }
        }
    }

    $addon->add_field('location_lat', 'Location - lat', 'text');
    $addon->add_field('location_lng', 'Location - lng', 'text');
    $addon->add_field('location_address', 'Address', 'text');

    $addon->import_images('gallery', 'Gallery', 'images',
        function ($postId, $attachmentId, $imageFilepath, $importOptions) {
            $gallery = get_post_meta($postId, 'estate_gallery', true);
            if ( ! is_array($gallery)) {
                $gallery = [];
            }
            $gallery[] = $attachmentId;
            update_post_meta($postId, 'estate_gallery', $gallery);
        }
    );

    $addon->set_import_function(function ($postId, $data, $importOptions, $article) {
        foreach (\MyHomeCore\Attributes\Attribute_Factory::get() as $attribute) {
            /* @var \MyHomeCore\Attributes\Attribute $attribute */
            if ($attribute instanceof \MyHomeCore\Attributes\Number_Attribute && isset($data[$attribute->get_ID()])) {
                update_post_meta($postId, 'estate_attr_'.$attribute->get_slug(), $data[$attribute->get_ID()]);
                continue;
            }

            foreach (myhome_get_price_keys() as $key => $label) {
                if (isset($data[$key])) {
                    update_post_meta($postId, 'estate_attr_'.$key, $data[$key]);
                }
            }
        }

        $map = array('zoom' => 5);
        if (isset($data['location_address'])) {
            $map['address'] = $data['location_address'];
        }

        if (isset($data['location_lat'])) {
            $map['lat'] = $data['location_lat'];
        }

        if (isset($data['location_lng'])) {
            $map['lng'] = $data['location_lng'];
        }

        update_field('myhome_estate_location', $map, $postId);
    });
}, 200);


function myhome_get_price_keys()
{
    $prices = [];
    $currencies = Currencies::get_all();
    $offer_types = Term_Factory::get_offer_types();
    $attribute = \MyHomeCore\Attributes\Attribute_Factory::get_price();

    foreach ($currencies as $currency) {
        $currency_key = $currency->get_key();
        if (Price_Attribute::is_range()) {
            $price_keys = array($currency_key.'_from', $currency_key.'_to');
        } else {
            $price_keys = array($currency_key);
        }
        $keys_count = count($price_keys);

        foreach ($price_keys as $key => $price_key) {
            $label = $attribute->get_name().' ('.$currency->get_sign().')';

            if ($keys_count == 2 && $key == 0) {
                $label .= ' '.esc_html__('from', 'myhome-core');
            } elseif ($keys_count == 2 && $key == 1) {
                $label .= ' '.esc_html__('to', 'myhome-core');
            }

            $prices[$price_key] = $label;
        }

        foreach ($offer_types as $offer_type) {
            if ( ! $offer_type->specify_price()) {
                continue;
            }

            if ($offer_type->is_price_range()) {
                $price_keys = array($currency_key.'_from', $currency_key.'_to');
            } else {
                $price_keys = array($currency_key);
            }

            $keys_count = count($price_keys);

            foreach ($price_keys as $key => $price_key) {
                $label = $attribute->get_name().' ('.$currency->get_sign().')';

                if ($keys_count == 2 && $key == 0) {
                    $label .= ' '.esc_html__('from', 'myhome-core');
                } elseif ($keys_count == 2 && $key == 1) {
                    $label .= ' '.esc_html__('to', 'myhome-core');
                }

                $label .= ' | '.$offer_type->get_name();

                $field_key = $price_key.'_offer_'.$offer_type->get_ID();


                $prices[$field_key] = $label;
            }
        }
    }

    return $prices;
}