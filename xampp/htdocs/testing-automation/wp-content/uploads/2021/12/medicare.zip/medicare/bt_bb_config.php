<?php

class BoldThemes_BB_Settings {
	public static $custom_content_elements = true;
}